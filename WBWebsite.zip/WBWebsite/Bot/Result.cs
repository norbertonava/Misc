﻿using System;

namespace Bot
{
    [Serializable]
    public class Result
    {
        public string Message { get; set; }
        public string Quote1 { get; set; }
        public string Quote2 { get; set; }
        public string Quote3 { get; set; }
    }
}
