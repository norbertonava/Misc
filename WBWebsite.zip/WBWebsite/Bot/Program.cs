﻿using System;
using System.Windows.Forms;

namespace Bot
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            string[] args = Environment.GetCommandLineArgs();
            Form1 form = new Form1();

            if (args.Length > 2)
            {
                form.FilePath = args[1];
                form.FileName = args[2];
            }
            Application.Run(form);
        }
    }
}
