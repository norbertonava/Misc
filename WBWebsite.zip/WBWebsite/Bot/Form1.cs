﻿using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace Bot
{
    public partial class Form1 : Form
    {
        public string FileName { get; set; }
        Input input;
        string htmlResult;
        //Thread thrd;
        //string property_state;
        //string zipcode;
        //bool is_single_residential;
        //bool is_owner_occupied;
        //string atypical_occupancy_type;
        //string foundation_type;
        //int replacement_cost_amt;
        //int building_coverage_amt;
        //string premium_period;
        public string[] Result;
        public string HtmlResult
        {
            get { return htmlResult; }
        }

        public string FilePath { get; internal set; }

        public Form1()
        {
            SetBrowserFeatureControl();
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Result = new string[] { "", "", "" };
            try
            {
                input = Serializer.DeSerializeObject<Input>(this.FilePath + "\\Tmp\\" + this.FileName + "_i.xml");
            }
            catch (Exception ex)
            {
                this.htmlResult = "Unexpected error:" + ex.Message;
                return;
            }

            webBrowser1.ScriptErrorsSuppressed = true;
            webBrowser1.ScrollBarsEnabled = true;
            webBrowser1.AllowNavigation = true;

            webBrowser1.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(webBrowser1_DocumentCompleted);
            webBrowser1.Navigate("http://www.privatemarketflood.com/calculate-your-own-premium", null, null, "User - Agent:Mozilla / 5.0(Windows NT 10.0; Win64; x64) AppleWebKit / 537.36(KHTML, like Gecko) Chrome / 59.0.3071.115 Safari / 537.36");
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            if (!string.IsNullOrEmpty(htmlResult))
                return;

            HtmlDocument doc = ((WebBrowser)sender).Document;
            try
            {
                SetProperties(doc);
                System.Windows.Forms.HtmlElement submit = FindSubmit(doc);

                if (submit != null)
                {
                    //One with deductible = 5000
                    //Next dedubtibale = 2000
                    //Next deductiable 2000 and contents_coverage_amt = 25000
                    Result[0] = GetQuote(doc, submit, 5000, 0);
                    Result[1] = GetQuote(doc, submit, 2000, 0);
                    Result[2] = GetQuote(doc, submit, 2000, 25000);
                    htmlResult = "OK";
                }
                else
                {
                    htmlResult = "Unexpected error: Data couldn't be submitted";
                }
            }
            catch (Exception ex)
            {
                htmlResult = "Unexpected error: " + ex.Message;
            }

            Serializer.SerializeObject<Result>(new Bot.Result { Message = htmlResult, Quote1 = Result[0], Quote2 = Result[1], Quote3 = Result[2] }, this.FilePath + "\\Tmp\\" + this.FileName + "_r.xml");
            this.Close();
        }

        #region [Methods used to parse the result]
        private string GetQuote(HtmlDocument doc, System.Windows.Forms.HtmlElement submit, int deductible, int contents_coverage_amt)
        {
            string quote = "Couldn't parse response";
            try
            {
                int index = -1;
                doc.GetElementById("deductible").SetAttribute("value", deductible.ToString()); //values=2000,5000
                doc.GetElementById("contents_coverage_amt").SetAttribute("value", contents_coverage_amt.ToString());
                submit.InvokeMember("click");

                index = doc.Body.InnerHtml.IndexOf("<p class=\"premium-line\">");

                if (index != -1)
                {
                    quote = doc.Body.InnerHtml.Substring(index);
                    index = quote.IndexOf("$");
                    if (index != -1)
                    {
                        quote = quote.Substring(quote.IndexOf("$"));
                        index = quote.IndexOf("</strong>");
                        if (index != -1)
                            quote = quote.Substring(0, index);
                    }
                }
            }
            catch
            {

            }

            return quote;
        }

        private void SetProperties(HtmlDocument doc)
        {
            doc.GetElementById("property_state").SetAttribute("value", this.input.Property_state);
            doc.GetElementById("zipcode").SetAttribute("value", this.input.Zipcode);
            if (this.input.Is_single_residential)
            {
                doc.GetElementById("is_single_residential_yes").InvokeMember("click");
                if (this.input.Is_owner_occupied)
                {
                    doc.GetElementById("is_owner_occupied_yes").InvokeMember("click");
                }
                else
                {
                    doc.GetElementById("is_owner_occupied_no").InvokeMember("click");
                }
            }
            else
            {
                doc.GetElementById("is_single_residential_no").InvokeMember("click");

                //values=twotofour, fiveplus, other_non_resident
                switch (this.input.Atypical_occupancy_type)
                {
                    case "twotofour":
                        doc.GetElementById("atypical_occupancy_type_twotofour").InvokeMember("click");
                        break;
                    case "fiveplus":
                        doc.GetElementById("atypical_occupancy_type_fiveplus").InvokeMember("click");
                        break;
                    default:
                        doc.GetElementById("atypical_occupancy_type_other_non_resident").InvokeMember("click");
                        break;
                }
            }

            doc.GetElementById("foundation_type").SetAttribute("value", this.input.Foundation_type);//values = 1a,2,3,4,5,6,7,8,9
            doc.GetElementById("replacement_cost_amt").SetAttribute("value", this.input.Replacement_cost_amt.ToString());
            doc.GetElementById("building_coverage_amt").SetAttribute("value", this.input.Building_coverage_amt.ToString());
            doc.GetElementById("premium_period").SetAttribute("value", this.input.Premium_period);//values =1,1_1yr_rl,1_2yr_rl,2,3
        }

        private System.Windows.Forms.HtmlElement FindSubmit(HtmlDocument doc)
        {
            HtmlElementCollection col = doc.GetElementsByTagName("input");
            System.Windows.Forms.HtmlElement submit = null;

            foreach (System.Windows.Forms.HtmlElement ele in col)
            {
                if (ele.GetAttribute("value").Equals("Calculate Premium"))
                {
                    submit = ele;
                }
            }

            return submit;
        }
        #endregion [Methods used to parse the result]

        #region Enable Javascript
        private void SetBrowserFeatureControlKey(string feature, string appName, uint value)
        {
            using (var key = Registry.CurrentUser.CreateSubKey(
                String.Concat(@"Software\Microsoft\Internet Explorer\Main\FeatureControl\", feature),
                RegistryKeyPermissionCheck.ReadWriteSubTree))
            {
                key.SetValue(appName, (UInt32)value, RegistryValueKind.DWord);
            }
        }

        private void SetBrowserFeatureControl()
        {
            // http://msdn.microsoft.com/en-us/library/ee330720(v=vs.85).aspx

            // FeatureControl settings are per-process
            var fileName = System.IO.Path.GetFileName(Process.GetCurrentProcess().MainModule.FileName);

            // make the control is not running inside Visual Studio Designer
            //if (String.Compare(fileName, "devenv.exe", true) == 0 || String.Compare(fileName, "XDesProc.exe", true) == 0)
            //    return;

            SetBrowserFeatureControlKey("FEATURE_BROWSER_EMULATION", fileName, GetBrowserEmulationMode());// Webpages containing standards-based !DOCTYPE directives are displayed in IE10 Standards mode.
            SetBrowserFeatureControlKey("FEATURE_AJAX_CONNECTIONEVENTS", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_ENABLE_CLIPCHILDREN_OPTIMIZATION", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_MANAGE_SCRIPT_CIRCULAR_REFS", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_DOMSTORAGE ", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_GPU_RENDERING ", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_IVIEWOBJECTDRAW_DMLT9_WITH_GDI  ", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_DISABLE_LEGACY_COMPRESSION", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_LOCALMACHINE_LOCKDOWN", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_BLOCK_LMZ_OBJECT", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_BLOCK_LMZ_SCRIPT", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_DISABLE_NAVIGATION_SOUNDS", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_SCRIPTURL_MITIGATION", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_SPELLCHECKING", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_STATUS_BAR_THROTTLING", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_TABBED_BROWSING", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_VALIDATE_NAVIGATE_URL", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_WEBOC_DOCUMENT_ZOOM", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_WEBOC_POPUPMANAGEMENT", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_WEBOC_MOVESIZECHILD", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_ADDON_MANAGEMENT", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_WEBSOCKET", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_WINDOW_RESTRICTIONS ", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_XMLHTTP", fileName, 1);
        }

        private UInt32 GetBrowserEmulationMode()
        {
            int browserVersion = 7;
            using (var ieKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Internet Explorer",
                RegistryKeyPermissionCheck.ReadSubTree,
                System.Security.AccessControl.RegistryRights.QueryValues))
            {
                var version = ieKey.GetValue("svcVersion");
                if (null == version)
                {
                    version = ieKey.GetValue("Version");
                    if (null == version)
                        throw new ApplicationException("Microsoft Internet Explorer is required!");
                }
                int.TryParse(version.ToString().Split('.')[0], out browserVersion);
            }

            UInt32 mode = 11000; // Internet Explorer 11. Webpages containing standards-based !DOCTYPE directives are displayed in IE11 Standards mode. Default value for Internet Explorer 11.
            switch (browserVersion)
            {
                case 7:
                    mode = 7000; // Webpages containing standards-based !DOCTYPE directives are displayed in IE7 Standards mode. Default value for applications hosting the WebBrowser Control.
                    break;
                case 8:
                    mode = 8000; // Webpages containing standards-based !DOCTYPE directives are displayed in IE8 mode. Default value for Internet Explorer 8
                    break;
                case 9:
                    mode = 9000; // Internet Explorer 9. Webpages containing standards-based !DOCTYPE directives are displayed in IE9 mode. Default value for Internet Explorer 9.
                    break;
                case 10:
                    mode = 10000; // Internet Explorer 10. Webpages containing standards-based !DOCTYPE directives are displayed in IE10 mode. Default value for Internet Explorer 10.
                    break;
                default:
                    // use IE11 mode by default
                    break;
            }

            return mode;
        }
        #endregion
    }
}