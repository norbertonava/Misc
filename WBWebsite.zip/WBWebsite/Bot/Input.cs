﻿using System;

namespace Bot
{
    [Serializable]
    public class Input
    {
        public string Property_state { get; set; }
        public string Zipcode { get; set; }
        public bool Is_single_residential { get; set; }
        public bool Is_owner_occupied { get; set; }
        public string Atypical_occupancy_type { get; set; }
        public string Foundation_type { get; set; }
        public int Replacement_cost_amt { get; set; }
        public int Building_coverage_amt { get; set; }
        public string Premium_period { get; set; }
    }
}