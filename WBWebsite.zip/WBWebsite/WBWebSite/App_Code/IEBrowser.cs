using System;
using System.Threading;
using System.Diagnostics;
using System.IO;

/// <summary>
/// IEBrowser derived from ApplicationContext supports message loop
/// </summary>
public class IEBrowser : System.Windows.Forms.ApplicationContext
{
    AutoResetEvent resultEvent;
    Input inp = null;
    string htmlResult;
    Thread thrd;
    //string property_state;
    //string zipcode;
    //bool is_single_residential;
    //bool is_owner_occupied;
    //string atypical_occupancy_type;
    //string foundation_type;
    //int replacement_cost_amt;
    //int building_coverage_amt;
    //string premium_period;
    string filePath;
    string fileName;
    public string[] Result;
    public string HtmlResult
    {
        get { return htmlResult; }
    }

    /// <summary>
    /// Generates a Webbrowser control to scrap
    /// </summary>
    /// <param name="resultEvent"></param>
    /// <param name="property_state">State name</param>
    /// <param name="zipcode">Zipcode</param>
    /// <param name="is_single_residential">Is this building a single family residence? </param>
    /// <param name="is_owner_occupied">Is this single family residence lived in by the owner for at least 292 days per year?</param>
    /// <param name="atypical_occupancy_type">Is this unit a (valid values: twotofour, fiveplus, other_non_resident) ? </param>
    /// <param name="foundation_type">Valid values: 1a,2,3,4,5,6,7,8,9</param>
    /// <param name="replacement_cost_amt">What is the Replacement Cost of the Building?:</param>
    /// <param name="building_coverage_amt">Amount of building coverage (in $100 increments)</param>
    /// <param name="contents_coverage_amt">Amount of contents coverage (in $100 increments)</param>
    /// <param name="deductible">Deductible. Valid valued: 2000, 5000</param>
    /// <param name="premium_period">Total Premium For (valid values: 1,1_1yr_rl,1_2yr_rl,2,3)</param>
    public IEBrowser(AutoResetEvent resultEvent, string property_state, string zipcode, 
        bool is_single_residential, bool is_owner_occupied, string atypical_occupancy_type, 
        string foundation_type, int replacement_cost_amt, int building_coverage_amt, 
        string premium_period, string filePath, string fileName)
    {
        this.Result = new string[] { string.Empty, string.Empty, string.Empty };

        this.filePath = filePath;
        this.fileName = fileName;
        this.resultEvent = resultEvent;
        inp = new Input();
        inp.Property_state = property_state;
        inp.Zipcode = zipcode;
        inp.Is_single_residential = is_single_residential;
        inp.Is_owner_occupied = is_owner_occupied;
        inp.Atypical_occupancy_type = atypical_occupancy_type;
        inp.Foundation_type = foundation_type;
        inp.Replacement_cost_amt = replacement_cost_amt;
        inp.Building_coverage_amt = building_coverage_amt;
        inp.Premium_period = premium_period;

        htmlResult = null;
        try
        {
            if (!Directory.Exists(filePath + "\\Tmp\\"))
                Directory.CreateDirectory(filePath + "\\Tmp\\");

            Serializer.SerializeObject<Input>(inp, filePath + "\\Tmp\\" + this.fileName + "_i.xml");
        }
        catch (Exception e)
        {
            this.htmlResult = "Unexepected error:" + e.Message;
            this.resultEvent.Set();
            return;
        }

        thrd = new Thread(new ThreadStart(
            delegate {
                Init();
                //System.Windows.Forms.Application.Run(this); 
            }));
        // set thread to STA state before starting
        thrd.SetApartmentState(ApartmentState.STA);
        thrd.Start();
    }

    // initialize the WebBrowser
    private void Init()
    {
        try
        {
            Process p = new Process();
            ProcessStartInfo info = new ProcessStartInfo(filePath + "\\Bot.exe");
            info.WindowStyle = ProcessWindowStyle.Hidden;
            info.Arguments = string.Format("{0} {1}", filePath, this.fileName);
            p.StartInfo = info;
            p.Start();
            p.WaitForExit(60000);


            Result res = Serializer.DeSerializeObject<Result>(filePath + "\\Tmp\\" + this.fileName + "_r.xml");

            this.htmlResult = res.Message;
            this.Result[0] = res.Quote1;
            this.Result[1] = res.Quote2;
            this.Result[2] = res.Quote3;

            if (p != null && !p.HasExited)
                p.Kill();

            if (File.Exists(filePath + "\\Tmp\\" + this.fileName + "_i.xml"))
                File.Delete(filePath + "\\Tmp\\" + this.fileName + "_i.xml");

            if (File.Exists(filePath + "\\Tmp\\" + this.fileName + "_r.xml"))
                File.Delete(filePath + "\\Tmp\\" + this.fileName + "_r.xml");
        }
        catch (Exception e)
        {
            this.htmlResult = "Unexpected error: " + e.Message;
        }
        this.resultEvent.Set();
    }
    
    // Dipose the WebBrowser control
    protected override void Dispose(bool disposing)
    {
        if (thrd != null)
        {
            thrd.Abort();
            thrd = null;
            return;
        }

        //ieBrowser.DocumentStream.Close();
        //System.Runtime.InteropServices.Marshal.Release(ieBrowser.Handle);
        //ieBrowser.Dispose();
        base.Dispose(disposing);
    }

    /*
    // DocumentCompleted event handle
    void IEBrowser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
    {
        HtmlDocument doc = ((WebBrowser)sender).Document;
        try
        {
            SetProperties(doc);
            System.Windows.Forms.HtmlElement submit = FindSubmit(doc);

            if (submit != null)
            {
                //One with deductible = 5000
                //Next dedubtibale = 2000
                //Next deductiable 2000 and contents_coverage_amt = 25000
                Result[0] = GetQuote(doc, submit, 5000, 0);
                Result[1] = GetQuote(doc, submit, 2000, 0);
                Result[2] = GetQuote(doc, submit, 2000, 25000);
                htmlResult = "Ok";
            }
            else
            {
                htmlResult = "Unexpected error: Data couldn't be submitted";
            }
        }
        catch(Exception ex)
        {
            htmlResult = "Unexpected error: " + ex.Message;
            Result [0] = "Unexpected error: " + ex.Message;
        }

        resultEvent.Set();
    }

    #region [Methods used to parse the result]
    private string GetQuote(HtmlDocument doc, System.Windows.Forms.HtmlElement submit, int deductible, int contents_coverage_amt)
    {
        string quote = "Couldn't parse response";
        try
        {
            int index = -1;
            doc.GetElementById("deductible").SetAttribute("value", deductible.ToString()); //values=2000,5000
            doc.GetElementById("contents_coverage_amt").SetAttribute("value", contents_coverage_amt.ToString());
            submit.InvokeMember("click");

            index = doc.Body.InnerHtml.IndexOf("<p class=\"premium-line\">");

            if (index != -1)
            {
                quote = doc.Body.InnerHtml.Substring(index);
                index = quote.IndexOf("$");
                if (index != -1)
                {
                    quote = quote.Substring(quote.IndexOf("$"));
                    index = quote.IndexOf("</strong>");
                    if (index != -1)
                        quote = quote.Substring(0, index);
                }
            }
        }
        catch
        {

        }

        return quote;
    }

    private void SetProperties(HtmlDocument doc)
    {
        doc.GetElementById("property_state").SetAttribute("value", this.property_state);
        doc.GetElementById("zipcode").SetAttribute("value", this.zipcode);
        if (this.is_single_residential)
        {
            doc.GetElementById("is_single_residential_yes").InvokeMember("click");
            if (this.is_owner_occupied)
            {
                doc.GetElementById("is_owner_occupied_yes").InvokeMember("click");
            }
            else
            {
                doc.GetElementById("is_owner_occupied_no").InvokeMember("click");
            }
        }
        else
        {
            doc.GetElementById("is_single_residential_no").InvokeMember("click");

            //values=twotofour, fiveplus, other_non_resident
            switch (atypical_occupancy_type)
            {
                case "twotofour":
                    doc.GetElementById("atypical_occupancy_type_twotofour").InvokeMember("click");
                    break;
                case "fiveplus":
                    doc.GetElementById("atypical_occupancy_type_fiveplus").InvokeMember("click");
                    break;
                default:
                    doc.GetElementById("atypical_occupancy_type_other_non_resident").InvokeMember("click");
                    break;
            }
        }

        doc.GetElementById("foundation_type").SetAttribute("value", foundation_type);//values = 1a,2,3,4,5,6,7,8,9
        doc.GetElementById("replacement_cost_amt").SetAttribute("value", replacement_cost_amt.ToString());
        doc.GetElementById("building_coverage_amt").SetAttribute("value", building_coverage_amt.ToString());
        doc.GetElementById("premium_period").SetAttribute("value", "1");//values =1,1_1yr_rl,1_2yr_rl,2,3
    }

    private System.Windows.Forms.HtmlElement FindSubmit(HtmlDocument doc)
    {
        HtmlElementCollection col = doc.GetElementsByTagName("input");
        System.Windows.Forms.HtmlElement submit = null;

        foreach (System.Windows.Forms.HtmlElement ele in col)
        {
            if (ele.GetAttribute("value").Equals("Calculate Premium"))
            {
                submit = ele;
            }
        }

        return submit;
    }
    #endregion [Methods used to parse the result]

    #region Enable Javascript
    private void SetBrowserFeatureControlKey(string feature, string appName, uint value)
    {
        using (var key = Registry.CurrentUser.CreateSubKey(
            String.Concat(@"Software\Microsoft\Internet Explorer\Main\FeatureControl\", feature),
            RegistryKeyPermissionCheck.ReadWriteSubTree))
        {
            key.SetValue(appName, (UInt32)value, RegistryValueKind.DWord);
        }
    }

    private void SetBrowserFeatureControl()
    {
        // http://msdn.microsoft.com/en-us/library/ee330720(v=vs.85).aspx

        // FeatureControl settings are per-process
        var fileName = System.IO.Path.GetFileName(Process.GetCurrentProcess().MainModule.FileName);

        // make the control is not running inside Visual Studio Designer
        //if (String.Compare(fileName, "devenv.exe", true) == 0 || String.Compare(fileName, "XDesProc.exe", true) == 0)
        //    return;

        SetBrowserFeatureControlKey("FEATURE_BROWSER_EMULATION", fileName, GetBrowserEmulationMode());// Webpages containing standards-based !DOCTYPE directives are displayed in IE10 Standards mode.
        SetBrowserFeatureControlKey("FEATURE_AJAX_CONNECTIONEVENTS", fileName, 1);
        SetBrowserFeatureControlKey("FEATURE_ENABLE_CLIPCHILDREN_OPTIMIZATION", fileName, 1);
        SetBrowserFeatureControlKey("FEATURE_MANAGE_SCRIPT_CIRCULAR_REFS", fileName, 1);
        SetBrowserFeatureControlKey("FEATURE_DOMSTORAGE ", fileName, 1);
        SetBrowserFeatureControlKey("FEATURE_GPU_RENDERING ", fileName, 1);
        SetBrowserFeatureControlKey("FEATURE_IVIEWOBJECTDRAW_DMLT9_WITH_GDI  ", fileName, 0);
        SetBrowserFeatureControlKey("FEATURE_DISABLE_LEGACY_COMPRESSION", fileName, 1);
        SetBrowserFeatureControlKey("FEATURE_LOCALMACHINE_LOCKDOWN", fileName, 0);
        SetBrowserFeatureControlKey("FEATURE_BLOCK_LMZ_OBJECT", fileName, 0);
        SetBrowserFeatureControlKey("FEATURE_BLOCK_LMZ_SCRIPT", fileName, 0);
        SetBrowserFeatureControlKey("FEATURE_DISABLE_NAVIGATION_SOUNDS", fileName, 1);
        SetBrowserFeatureControlKey("FEATURE_SCRIPTURL_MITIGATION", fileName, 1);
        SetBrowserFeatureControlKey("FEATURE_SPELLCHECKING", fileName, 0);
        SetBrowserFeatureControlKey("FEATURE_STATUS_BAR_THROTTLING", fileName, 1);
        SetBrowserFeatureControlKey("FEATURE_TABBED_BROWSING", fileName, 1);
        SetBrowserFeatureControlKey("FEATURE_VALIDATE_NAVIGATE_URL", fileName, 1);
        SetBrowserFeatureControlKey("FEATURE_WEBOC_DOCUMENT_ZOOM", fileName, 1);
        SetBrowserFeatureControlKey("FEATURE_WEBOC_POPUPMANAGEMENT", fileName, 0);
        SetBrowserFeatureControlKey("FEATURE_WEBOC_MOVESIZECHILD", fileName, 1);
        SetBrowserFeatureControlKey("FEATURE_ADDON_MANAGEMENT", fileName, 0);
        SetBrowserFeatureControlKey("FEATURE_WEBSOCKET", fileName, 1);
        SetBrowserFeatureControlKey("FEATURE_WINDOW_RESTRICTIONS ", fileName, 0);
        SetBrowserFeatureControlKey("FEATURE_XMLHTTP", fileName, 1);
    }

    private UInt32 GetBrowserEmulationMode()
    {
        int browserVersion = 7;
        using (var ieKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Internet Explorer",
            RegistryKeyPermissionCheck.ReadSubTree,
            System.Security.AccessControl.RegistryRights.QueryValues))
        {
            var version = ieKey.GetValue("svcVersion");
            if (null == version)
            {
                version = ieKey.GetValue("Version");
                if (null == version)
                    throw new ApplicationException("Microsoft Internet Explorer is required!");
            }
            int.TryParse(version.ToString().Split('.')[0], out browserVersion);
        }

        UInt32 mode = 11000; // Internet Explorer 11. Webpages containing standards-based !DOCTYPE directives are displayed in IE11 Standards mode. Default value for Internet Explorer 11.
        switch (browserVersion)
        {
            case 7:
                mode = 7000; // Webpages containing standards-based !DOCTYPE directives are displayed in IE7 Standards mode. Default value for applications hosting the WebBrowser Control.
                break;
            case 8:
                mode = 8000; // Webpages containing standards-based !DOCTYPE directives are displayed in IE8 mode. Default value for Internet Explorer 8
                break;
            case 9:
                mode = 9000; // Internet Explorer 9. Webpages containing standards-based !DOCTYPE directives are displayed in IE9 mode. Default value for Internet Explorer 9.
                break;
            case 10:
                mode = 10000; // Internet Explorer 10. Webpages containing standards-based !DOCTYPE directives are displayed in IE10 mode. Default value for Internet Explorer 10.
                break;
            default:
                // use IE11 mode by default
                break;
        }

        return mode;
    }
    #endregion

    */
}
