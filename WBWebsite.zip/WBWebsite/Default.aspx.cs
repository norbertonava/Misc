using System;
using System.Configuration;
using System.Threading;
using System.Web.Script.Services;

public partial class _Default : System.Web.UI.Page
{
    [System.Web.Services.WebMethod]
    [ScriptMethod(UseHttpGet = false)]
    public static string[] GetQuote(string property_state, string zipcode, bool is_single_residential, 
        bool is_owner_occupied, string atypical_occupancy_type, string foundation_type, 
        int replacement_cost_amt, int building_coverage_amt, string premium_period)
    {

        AutoResetEvent resultEvent = new AutoResetEvent(false);
        string fileName = Guid.NewGuid().ToString();
        string filePath = ConfigurationManager.AppSettings["botPath"].ToString();
        IEBrowser browser = new IEBrowser(resultEvent, property_state, zipcode,
                                        is_single_residential, is_owner_occupied, 
                                        atypical_occupancy_type,
                                        foundation_type, replacement_cost_amt, 
                                        building_coverage_amt, premium_period, filePath, fileName);

        // wait for the third thread getting result and setting result event
        EventWaitHandle.WaitAll(new AutoResetEvent[] { resultEvent });
        // the result is ready later than the result event setting sometimes 
        while (browser == null || browser.HtmlResult == null) Thread.Sleep(5);

        string[] result = browser.Result;

        if (browser != null) browser.Dispose();

        return result;
    }
}